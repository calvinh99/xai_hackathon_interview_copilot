// Bot configuration for x.ai WebSocket connection
const config = {
  // Initial conversation instructions
  instructions: `You are a helpful voice assistant. You are speaking to a user in real-time over audio. Keep your responses conversational and concise since they will be spoken aloud.`,
};

export default config;
